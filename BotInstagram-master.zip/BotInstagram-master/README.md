$ pkg update && pkg upgrade

$ pkg install nodejs git unzip -y

$ termux-setup-storage

$ git clone https://github.com/Allfaton/BotInstagram

$ cd BotInstagram

$ npm install

$ npm install nodejs

$ npm install audit fix

$ npm install audit fix --force

$ unzip node modules.zip (tunggu proses hingga selesai
  lalu klik [A] ENTER)

$ npm instagram-private-api

$ node index
